<?php

$host = "localhost";
$user = "root";
$pass = "";
$db = "menu";

$dbconnect =new mysqli("$host","$user","$pass","$db");





?>