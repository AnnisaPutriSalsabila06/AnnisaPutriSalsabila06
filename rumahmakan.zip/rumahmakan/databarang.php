<!doctype html>
<!DOCTYPE html>
<html>
<head>
 <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Creative - Start Bootstrap Theme</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Bootstrap Icons-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Merriweather+Sans:400,700" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic" rel="stylesheet" type="text/css" />
        <!-- SimpleLightbox plugin CSS-->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/SimpleLightbox/2.1.0/simpleLightbox.min.css" rel="stylesheet" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
    </head>

	<!-- Bootsrap core CSS-->

<link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.min.css">

    <style>
    	.bd-placeholder-img {
    		font-size: 1.125rem;
    		text-anchor: middle;
    		-webkit-user-select: none;
    		-moz-user-select: none;
    		user-select: none;
    	}


    	@media (min-width: 768px) {
    		.bd-placeholder-img-lg {
    			font-size: 3.5rem;
    		}
    	}
    </style>



    <!-- Custom styles for this template -->
    <link href="dashboard.css" rel="stylesheet">
</head>
<body>


		

		<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
			<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
				<h1 class="h2">Data Menu</h1>
			</div>
			<a href="inputdata.php" class="btn btn-primary">Masukan Makanan</a>
				<div class="card-body">
			<table class="table table-bordered table-responsive-x1 table-hover display">
				<thead>
    			<tr>
    				<th>Kede Makanan</th>
    				<th>Nama Makanan</th>
   					<th>Jumlah</th>
   					<th>Harga</th>
   					<th>Supplier</th>
   					<th>Aksi</th>

    			</tr>
    			</thead>
    			<tbody>
<?php
include 'koneksi.php';
			$no = 1;
				$number = mysqli_query($dbconnect, "SELECT * FROM menu_makanan");


				while ($query = mysqli_fetch_assoc($number)) {
					?> 	

				<form action="databarang.php" method="post">
					<tr>
						
						<td><?php echo $query ['kode_makanan'];?></td>
						<td><?php echo $query ['nama_makanan'];?></td>
						<td><?php echo $query ['jumlah'];?></td>
						<td><?php echo $query ['harga'];?></td>
						<td><?php echo $query ['supplier'];?></td>
						
						
						<td>
							<a href="updatedata.php?nama_makanan=<?php echo $query ['nama_makanan']?>" class="btn btn-primary">Edit</a>
							<a href="proseshapusdata.php?nama_makanan=<?php echo $query ['nama_makanan']?>" class="btn btn-danger" onclick ="return confirm('apakah anda yakin ingin menghapus data? dengan nama_makanan <?php echo $query ['nama_makanan']?>')">Hapus</a>
						</td>
					</tr>
				</form>	
				<?php }  ?>		
    			</tbody>
    			</table>
    			</div>
		</main>
	</div>
    </div>
    	
    <script type="text/javascript" src="../assets/js/bootstrap.bundle.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/feather-icons@4.28.0/dist/feather.min.js" integrity="sha384-u03SXW5IuS1ZpFPKugNNWqTZRRgInUJK6UAZ/gxOX80nxEkN9NcGZTftn6RzhGWE" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js" integrity="sha384-zNy6FEbO50N+Cg5wap8IKA4M/ZnLJgzc6w2NqACZaK0u0FXfOWRRJOnQtpZun8ha" crossorigin="anonymous"></script>
    <script src="dashboard.js"></script>
</body>
</html>