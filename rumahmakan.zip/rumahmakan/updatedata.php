<!doctype html>
<!DOCTYPE html>
<html>
<head>
 <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Creative - Start Bootstrap Theme</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Bootstrap Icons-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Merriweather+Sans:400,700" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic" rel="stylesheet" type="text/css" />
        <!-- SimpleLightbox plugin CSS-->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/SimpleLightbox/2.1.0/simpleLightbox.min.css" rel="stylesheet" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
    </head>
</head>
<body>



		<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
			<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
				<h1 class="h2">Edit Data Barang</h1>
			</div>
			<section>
				<form action="prosesupdate.php" method="post">
					<!-- Edit  -->
					<?php
					include 'koneksi.php';
					$nama_makanan=$_GET['nama_makanan'];
					$query = mysqli_query($dbconnect, "SELECT * FROM menu_makanan WHERE nama_makanan = '$nama_makanan' ");
					$tampil = mysqli_fetch_assoc($query);
					?>
					<section>
						<section>
							<section>
									<div class="mb-3">
									<label for="kode_makanan" class="form-label">Kode Makanan</label>
									<input type="text" class="form-control" id="kode_makanan" name="kode_makanan" required autocomplete="off" value="<?php echo $tampil['kode_makanan']?>">
								</div>
								<div class="mb-3">
									<label for="nama_makanan" class="form-label">Nama Makanan</label>
									<input type="text" class="form-control" id="nama_makanan" name="nama_makanan" required autocomplete="off" value="<?php echo $tampil['nama_makanan']?>">
								</div>
								<div class="mb-3">
									<label for="jumlah" class="form-label">jumlah</label>
									<input type="text" class="form-control" id="jumlah" name="jumlah" required autocomplete="off" value="<?php echo $tampil['jumlah']?>">
								</div>
								<div class="mb-3">
									<label for="harga" class="form-label">Harga</label>
									<input type="text" class="form-control" id="harga" name="harga" required autocomplete="off" value="<?php echo $tampil['harga']?>">
								</div>
								<div class="mb-3">
									<label for="supplier" class="form-label">Supplier</label>
									<input type="text" class="form-control" id="supplier" name="supplier" required autocomplete="off" value="<?php echo $tampil['supplier']?>">
								</div>
					
								<div class="mb-3">
									<button type="submit" name="inputdata" class="btn btn-primary" onclick="return confirm('apakah anda yakin ingin mengubah data tersebut ? ')">Ubah</button>
								</div>
							</section>
						</section>
					</section>
				</form>
			</section>
		</main>
	</div>
    </div>
    	
    <script type="text/javascript" src="../assets/js/bootstrap.bundle.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/feather-icons@4.28.0/dist/feather.min.js" integrity="sha384-u03SXW5IuS1ZpFPKugNNWqTZRRgInUJK6UAZ/gxOX80nxEkN9NcGZTftn6RzhGWE" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js" integrity="sha384-zNy6FEbO50N+Cg5wap8IKA4M/ZnLJgzc6w2NqACZaK0u0FXfOWRRJOnQtpZun8ha" crossorigin="anonymous"></script>
    <script src="dashboard.js"></script>
</body>
</html>