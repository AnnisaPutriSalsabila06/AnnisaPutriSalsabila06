<?php include 'koneksi.php';


$nama=$_GET['nama_makanan'];

//Menghapus data
mysqli_query ($dbconnect, "DELETE FROM `menu_makanan` WHERE nama_makanan = '$nama'"); 


header("location:databarang.php");

?>
