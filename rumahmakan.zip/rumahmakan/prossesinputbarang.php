<?php

include 'koneksi.php';


$kode_makanan= $_POST['kode_makanan'];

$nama_makanan= $_POST['nama_makanan'];
$jumlah= $_POST['jumlah'];
$harga= $_POST['harga'];
$supplier= $_POST['supplier'];




mysqli_query($dbconnect, "INSERT INTO `menu_makanan`(`kode_makanan`, `nama_makanan`, `jumlah`, `harga`, `supplier`) VALUES ('$kode_makanan','$nama_makanan','$jumlah','$harga','$supplier')" );

	header("location:databarang.php");
	?>