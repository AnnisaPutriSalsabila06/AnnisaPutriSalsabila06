<?php
include 'koneksi.php';

$kode_makanan= $_POST['kode_makanan'];

$nama_makanan= $_POST['nama_makanan'];
$jumlah= $_POST['jumlah'];
$harga= $_POST['harga'];
$supplier= $_POST['supplier'];






mysqli_query($dbconnect, "UPDATE `menu_makanan` SET `kode_makanan`='$kode_makanan	',`nama_makanan`='$nama_makanan',`jumlah`='$jumlah',`harga`='$harga',`supplier`='$supplier' ");

header("location:databarang.php");
?>
